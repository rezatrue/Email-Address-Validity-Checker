<?php
class Profileemail{

	// database connection and table name
	private $conn;
	private $table_name = "ev_profile_email";

	// people properties
	public $serialNo;	
	public $userId;
	public $emailAddress;
	public $profileLink;
	public $emailStatus;
	public $updatedTime;
	
	// constructor with $db as database connection
	public function __construct($db){
		$this->conn = $db;
	}
	

	function read(){
	// select all query
	$query = "SELECT *	FROM
				" . $this->table_name . " ORDER BY serialNo ASC";
	// prepare query statement
	$stmt = $this->conn->prepare($query);
	// execute query
	$stmt->execute();
	return $stmt;
	}
	
	// create product
	function addProfileemail(){
 
    // query to insert record
    $query = "INSERT INTO
                " . $this->table_name . "
            SET
                userId=:uid, emailAddress=:email, profileLink=:plink, emailStatus=:status, updatedTime=:updated";
 
    // prepare query
    $stmt = $this->conn->prepare($query);

    // sanitize serialNo=:serial, 
    //$this->serialNo=htmlspecialchars(strip_tags($this->serialNo));
	$this->userId=htmlspecialchars(strip_tags($this->userId));
	$this->emailAddress=htmlspecialchars(strip_tags($this->emailAddress));
    $this->profileLink=htmlspecialchars(strip_tags($this->profileLink));
	$this->emailStatus=htmlspecialchars(strip_tags($this->emailStatus));
    $this->updatedTime=htmlspecialchars(strip_tags($this->updatedTime));
	
	// bind values
    //$stmt->bindParam(":serial", $this->serialNo);
	$stmt->bindParam(":uid", $this->userId);
	$stmt->bindParam(":email", $this->emailAddress);
    $stmt->bindParam(":plink", $this->profileLink);
	$stmt->bindParam(":status", $this->emailStatus);
	$stmt->bindParam(":updated", $this->updatedTime);
	
    // execute query
    if($stmt->execute()){
        return true;
    }
 
    return false;
     
}

// ................. not useing ....................

	function peopeBySalesProfile($salesProfileUrl){

	// select res name
	$query = "SELECT * FROM " . $this->table_name . " WHERE salesProfile = ?";
	// prepare query statement
	$stmt = $this->conn->prepare($query);

	$stmt->bindParam(1, $salesProfileUrl);
	// execute query
	$stmt->execute();

	return $stmt;
	}



	function peopeBypublicProfile($publicProfileUrl){

	// select res name
	$query = "SELECT * FROM " . $this->table_name . " WHERE publicProfile = ?";
	// prepare query statement
	$stmt = $this->conn->prepare($query);

	$stmt->bindParam(1, $publicProfileUrl);
	// execute query
	$stmt->execute();

	return $stmt;
	}




	function readWithId($peopleSerialNo){

	$query = "SELECT
				peopleSerialNo, salesProfile, publicProfile, firstName, lastName, email, phone, location, industry, currentJobTitle, currentCompany, companySize, firstCreatedTime, lastUpdatedTime
			FROM
				" . $this->table_name . " WHERE peopleSerialNo = ?";

	// prepare query statement
	$stmt = $this->conn->prepare($query);

	$stmt->bindParam(1, $peopleSerialNo);
	
	// execute query
	$stmt->execute();

	return $stmt;
	
	}

	function editPeople($peopleSerialNo){

	    // query to update record
    $query = "UPDATE
                " . $this->table_name . "
            SET
                salesProfile=:salesPro, publicProfile=:publicPro, firstName=:fName, lastName=:lName, email=:email, phone=:phone, location=:location, industry=:industry, currentJobTitle=:title, currentCompany=:company, companySize=:csize, lastUpdatedTime=:updated"
				. " WHERE peopleSerialNo =:peopleid";
 
   	// prepare query
    $stmt = $this->conn->prepare($query);

    // sanitize
	$this->salesProfile=htmlspecialchars(strip_tags($this->salesProfile));
	$this->publicProfile=htmlspecialchars(strip_tags($this->publicProfile));
	$this->firstName=htmlspecialchars(strip_tags($this->firstName));
    $this->lastName=htmlspecialchars(strip_tags($this->lastName));
	$this->email=htmlspecialchars(strip_tags($this->email));
    $this->phone=htmlspecialchars(strip_tags($this->phone));
    $this->location=htmlspecialchars(strip_tags($this->location));
    $this->industry=htmlspecialchars(strip_tags($this->industry));
    $this->currentJobTitle=htmlspecialchars(strip_tags($this->currentJobTitle));
	$this->currentCompany=htmlspecialchars(strip_tags($this->currentCompany));
    $this->companySize=htmlspecialchars(strip_tags($this->companySize));
    $this->lastUpdatedTime=htmlspecialchars(strip_tags($this->lastUpdatedTime));
	
	// bind values	
	$stmt->bindParam(":salesPro", $this->salesProfile);
	$stmt->bindParam(":publicPro", $this->publicProfile);
	$stmt->bindParam(":fName", $this->firstName);
    $stmt->bindParam(":lName", $this->lastName);
	$stmt->bindParam(":email", $this->email);
    $stmt->bindParam(":phone", $this->phone);
    $stmt->bindParam(":location", $this->location);
    $stmt->bindParam(":industry", $this->industry);
	$stmt->bindParam(":title", $this->currentJobTitle);
	$stmt->bindParam(":company", $this->currentCompany);
    $stmt->bindParam(":csize", $this->companySize);
	$stmt->bindParam(":updated", $this->lastUpdatedTime);
	
	
	$stmt->bindParam(":peopleid", $peopleSerialNo);

	
	// execute query
    if($stmt->execute()){
        return true;
    }

    return false;
	}
		
}