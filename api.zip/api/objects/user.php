<?php
class User{

	// database connection and table name
	private $conn;
	private $table_name = "ev_users";

	// user properties
	public $userSerialNo;
	public $userEmail;
	public $userName;
	public $userPassword;
	public $userPhone;
	public $userCreated;
	public $userLimits;
	public $userUsage;
	public $userExpaired;


	
	// constructor with $db as database connection
	public function __construct($db){
		$this->conn = $db;
	}
	
// login user
	function login($email, $password){

	// select all query
	$query = "SELECT userSerialNo, userName , userLimits, userUsage, userExpaired FROM 
				" . $this->table_name . " WHERE userEmail = ? AND userPassword = ? ORDER BY userSerialNo ASC";
	
	// prepare query statement
	$stmt = $this->conn->prepare($query);
	
	$stmt->bindParam(1, $email);
	$stmt->bindParam(2, $password);
	
	// execute query
	$stmt->execute();

	return $stmt;
}


// .......not using ....................	

	// read users
	function read(){

	// select all query
	$query = "SELECT
				userSerialNo, userName, userPassword, userPhone, userCreated, userLimits, userUsage, userExpaired
			FROM
				" . $this->table_name . " ORDER BY userSerialNo ASC";

	// prepare query statement
	$stmt = $this->conn->prepare($query);

	// execute query
	$stmt->execute();

	return $stmt;
}


	// user search with id
	function searchUser($userSerialNo){

	// select all query
	$query = "SELECT userSerialNo, userName, userEmail, userPhone, userCreated, userLimits, userUsage, userExpaired FROM
				" . $this->table_name . " WHERE userSerialNo = ? ";

	// prepare query statement
	$stmt = $this->conn->prepare($query);

	$stmt->bindParam(1, $userSerialNo);
	
	// execute query
	$stmt->execute();

	return $stmt;
}


	// search user id
	function searchUserId($userPhone){

	// select all query
	$query = "SELECT userSerialNo FROM
				" . $this->table_name . " WHERE userPhone = ? ";

	// prepare query statement
	$stmt = $this->conn->prepare($query);

	$stmt->bindParam(1, $userPhone);
	
	// execute query
	$stmt->execute();

	return $stmt;
}


	// usage update
	function usageupdate($email, $password, $new_usage){

	$query = "UPDATE " . $this->table_name . " set userUsage = userUsage + ? WHERE userEmail = ? AND userPassword = ?";
	
	// prepare query statement
	$stmt = $this->conn->prepare($query);
	
	$stmt->bindParam(1, $new_usage);
	$stmt->bindParam(2, $email);
	$stmt->bindParam(3, $password);
	
	// execute query
	$res = $stmt->execute();

	if($res == 1){
		return $this->login($email, $password);
	}else if ($res > 1){
		$queryrollback = "ROLLBACK";
		$this->conn->prepare($queryrollback);
		return "no_change";
	}else {
		return "no_change";
	}

}
	
	// create product
	function createuser(){
 
    // query to insert record
    $query = "INSERT INTO
                " . $this->table_name . "
            SET
                userName=:name, userEmail=:email, userPassword=:password, userPhone=:phone, userCreated=:created, userUsage=:use, userLimits=:limits, userExpaired=:expaired";
 
    // prepare query
    $stmt = $this->conn->prepare($query);
 
    // sanitize
    $this->userName=htmlspecialchars(strip_tags($this->userName));
	$this->userEmail=htmlspecialchars(strip_tags($this->userEmail));
	$this->userPassword=htmlspecialchars(strip_tags($this->userPassword));
    $this->userPhone=htmlspecialchars(strip_tags($this->userPhone));
    $this->userCreated=htmlspecialchars(strip_tags($this->userCreated));
	$this->userLimits=htmlspecialchars(strip_tags($this->userLimits));
	$this->userUsage=htmlspecialchars(strip_tags($this->userUsage));
    $this->userExpaired=htmlspecialchars(strip_tags($this->userExpaired));
    
	// bind values
    $stmt->bindParam(":name", $this->userName);
	$stmt->bindParam(":email", $this->userEmail);
	$stmt->bindParam(":password", $this->userPassword);
    $stmt->bindParam(":phone", $this->userPhone);
    $stmt->bindParam(":created", $this->userCreated);
	$stmt->bindParam(":limits", $this->userLimits);
	$stmt->bindParam(":use", $this->userUsage);
    $stmt->bindParam(":expaired", $this->userExpaired);
	
    // execute query
    if($stmt->execute()){
        return true;
    }
 
    return false;
     
}
	
	
}