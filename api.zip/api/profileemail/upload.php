<?php
// required headers
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Max-Age: 3600");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
 
// get database connection
include_once '../config/database.php';
 
// instantiate product object
include_once '../objects/profileemail.php';


$database = new Database();
$db = $database->getConnection();
 
$profileemail = new Profileemail($db);
 
// get posted data
$receiveddata = json_decode(file_get_contents("php://input"));


if($receiveddata->name == "profile_email"){
	
	$jsondata = $receiveddata->data;
	
	$count = 0;
	foreach ($jsondata as &$item) {
		
		$count++;
		//$profileemail->serialNo = $item->profileemail->serialNo;
		$profileemail->userId = $item->userId;
		$profileemail->emailAddress = $item->emailAddress;
		$profileemail->profileLink = $item->profileLink;
		$profileemail->emailStatus = $item->emailStatus;
		$profileemail->updatedTime = date('Y-m-d H:i:s');
		$profileemail->addProfileemail();
	}
	
	// response status
	$status = "ok";
	$total = $count;
}else{
	$status = "failed";
	$total = 0;
}

echo json_encode(array("status" => $status ,"total" => $total));


?>